ALTER TABLE `#__phocagallery_categories` ADD COLUMN `image_id` int(11) NOT NULL default 0;


