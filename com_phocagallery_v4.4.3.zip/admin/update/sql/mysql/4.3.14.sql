ALTER TABLE `#__phocagallery_categories` ADD COLUMN `imgurclient` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `#__phocagallery_categories` ADD COLUMN `imguralbum` varchar(255) NOT NULL DEFAULT '';
